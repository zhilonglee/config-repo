package com.ncs.zhilong.customingpropertiessourcelocatordemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomingPropertiesSourceLocatorDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomingPropertiesSourceLocatorDemoApplication.class, args);
	}
}
